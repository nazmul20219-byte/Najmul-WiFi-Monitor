# Najmul WiFi Monitor — Android starter

This is the first Android Studio source starter for the bilingual (Bangla/English) app.

## What this first build does
- Shows a device's network byte counters using Android `TrafficStats`.
- Stores daily counter snapshots locally and calculates daily deltas.
- Lets the user switch Bangla / English.
- Shows device name and today's estimated usage.

## Important limitation
Android's public `TrafficStats` counters are device-wide totals, not guaranteed Wi-Fi-only totals. They can include mobile data and may reset after reboot. Therefore this starter does **not** yet claim exact per-device Wi-Fi usage from the Tenda F3 router.

To build the full system, each Android phone will need the companion app installed and paired with the admin phone. The next stage is secure local-network reporting and Wi-Fi-only accounting validation on the target Android versions. Tenda F3 firmware shown in the user's screenshots does not expose per-client traffic totals, so the router itself cannot provide the missing figures.

## Open in Android Studio
Open this folder as an existing project. It uses a standard Android Gradle project structure. If Android Studio asks to update Gradle/Android Gradle Plugin, accept its compatible recommendation.
