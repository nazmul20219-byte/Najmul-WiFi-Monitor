plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.najmul.wifimonitor"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.najmul.wifimonitor"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
